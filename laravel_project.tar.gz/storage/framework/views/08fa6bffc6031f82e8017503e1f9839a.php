<?php $__env->startSection('content'); ?>
    <!-- content @s -->
    <div class="nk-content nk-content-fluid">
        <div class="container-xl wide-xl">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head nk-block-head-sm">
                        <div class="nk-block-between">
                            <div class="nk-block-head-content">
                                <h3 class="nk-block-title page-title">All App Record</h3>
                            </div><!-- .nk-block-head-content -->
                            <div class="nk-block-head-content">
                                <div class="toggle-wrap nk-block-tools-toggle">
                                    <a href="#" class="btn btn-icon btn-trigger toggle-expand me-n1"
                                        data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                                    <div class="toggle-expand-content" data-content="pageMenu">
                                        <ul class="nk-block-tools g-3">
                                            <li>
                                                <div class="form-control-wrap">
                                                    <div class="form-icon form-icon-right">
                                                        <em class="icon ni ni-search"></em>
                                                    </div>
                                                    <input type="text" class="form-control" id="myInput"
                                                        placeholder="Quick search by id">
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div><!-- .nk-block-head-content -->
                        </div><!-- .nk-block-between -->
                    </div><!-- .nk-block-head -->
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success mt-4"><strong><?php echo e(Session::get('success')); ?></strong></div>
                    <?php endif; ?>
                    <?php if(Session::has('fail')): ?>
                        <div class="alert alert-danger mt-4"><strong><?php echo e(Session::get('fail')); ?></strong></div>
                    <?php endif; ?>
                    <div class="nk-block">
                        <div class="card card-bordered">
                            <div class="card-inner-group">
                                <div class="card-inner p-0">
                                    <div class="nk-tb-list" id="table_search">
                                        <div class="nk-tb-item nk-tb-head">

                                            <div class="nk-tb-col tb-col-sm"><span>App id</span></div>
                                            <div class="nk-tb-col"><span>Operating System</span></div>
                                            <div class="nk-tb-col"><span>Created At</span></div>
                                            <div class="nk-tb-col"><span>Status</span></div>
                                            <div class="nk-tb-col"><span>Assign Url</span></div>


                                        </div><!-- .nk-tb-item -->
                                        <?php if(isset($data)): ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <div class="nk-tb-item tr_cust">

                                                    <div class="nk-tb-col tb-col-sm">
                                                        <span class="tb-product">
                                                            <span class="title"><?php echo e($row->app_id); ?></span>
                                                        </span>
                                                    </div>

                                                    <div class="nk-tb-col">
                                                        <span class="tb-sub"><?php echo e($row->os); ?></span>
                                                    </div>
                                                    <div class="nk-tb-col">
                                                        <span
                                                            class="tb-sub"><?php echo e($row->created_at ? date('M j, Y', strtotime($row->created_at)) : 'null'); ?></span>
                                                    </div>
                                                    <div class="nk-tb-col">
                                                        <div
                                                            class="custom-control custom-switch me-n2 <?php echo e($row->status == 'enable' ? 'checked' : ''); ?>">
                                                            <input type="checkbox" class="custom-control-input toggle-switch"
                                                                data-id="<?php echo e($row->id); ?>"
                                                                <?php echo e($row->status == 'enable' ? 'checked' : ''); ?>

                                                                id="activity-log"><label class="custom-control-label"
                                                                for="activity-log"></label>
                                                        </div>
                                                        
                                                    </div>

                                                    <div class="nk-tb-col">
                                                        <div class="drodown"><a href="#"
                                                                class="dropdown-toggle btn btn-icon btn-trigger"
                                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                                <?php if(isset($row->assign_url)): ?>
                                                                    <em class="icon ni ni-edit"></em>
                                                                <?php else: ?>
                                                                    <em class="icon ni ni-plus"></em>
                                                                <?php endif; ?>

                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end"
                                                                style="width: 300px;padding: 17px;border-radius: 13px;">
                                                                <form action="<?php echo e(route('update.url', $row->id)); ?>"
                                                                    method="POST" class="form-validate is-alter"
                                                                    novalidate="novalidate">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="form-group"><label class="form-label"
                                                                            for="full-name">URL</label>
                                                                        <div class="form-control-wrap"><input type="text"
                                                                                class="form-control assign_id" name="assign_url"
                                                                                value="<?php echo e($row->assign_url); ?>"></div>
                                                                    </div>

                                                                    <div class="form-group"><button type="submit"
                                                                            class="btn btn-lg btn-primary">Save
                                                                        </button></div>
                                                                </form>
                                                            </div>
                                                        </div>

                                                    </div>










                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </div><!-- .nk-tb-list -->
                                </div>

                            </div>
                        </div>
                    </div><!-- .nk-block -->

                </div>
            </div>
        </div>
    </div>
    <!-- content @e -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_content'); ?>
    <script>
        $(document).ready(function() {
            $("#myInput").on("keyup", function() {

                var value = $(this).val().toLowerCase();
                $("#table_search .tr_cust").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });


        $(".toggle-switch").on("change", function() {
            var itemId = $(this).data("id");
            var status = $(this).prop("checked") ? "enable" : 'disable'; // Get switch status

            $.ajax({
                url: "<?php echo e(route('switch.update')); ?>",
                type: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: itemId,
                    status: status
                },
                success: function(response) {

                    Swal.fire({
                        position: "top-end",
                        icon: "success",
                        title: response.message,
                        showConfirmButton: false,
                        timer: 1500
                    });
                    // alert(response.message);
                },
                error: function(xhr) {
                    alert("Something went wrong!");
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\allprojects\ggPlayerDashboard\resources\views/index.blade.php ENDPATH**/ ?>