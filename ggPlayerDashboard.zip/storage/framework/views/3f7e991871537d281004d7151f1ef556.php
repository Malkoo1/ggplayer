<?php $__env->startSection('content'); ?>
<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between g-3">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">Update Password</h3>
                        </div>
                    </div>
                </div>
                <!--.nk-block-head -->
                <?php if(Session::has('success')): ?>
                <div class="alert alert-success mt-4"><strong><?php echo e(Session::get('success')); ?></strong></div>
                <?php endif; ?>
                <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger mt-4"><strong><?php echo e(Session::get('fail')); ?></strong></div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="nk-block">
                            <div class="card">
                                <div class="card-inner">
                                    <form action="<?php echo e(route('update.crend')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row gy-4">


                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="form-label" for="">Email</label>
                                                    <input type="email" class="form-control" name="email" value="<?php echo e(auth()->user()->email); ?>" placeholder="Enter Email">
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback d-block" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                             <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="form-label" for="">Current Password</label>
                                                    <input type="password" class="form-control" name="current_password" placeholder="Enter Current Password">
                                                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback d-block" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="form-label" for="">New Password</label>
                                                    <input type="password" class="form-control" name="new_password" placeholder="Enter New Password">
                                                    <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback d-block" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="form-label" for="">New Confirm Password</label>
                                                    <input type="password" class="form-control" name="new_confirm_password" placeholder="Enter New Confirm Password">
                                                    <?php $__errorArgs = ['new_confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback d-block" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>



                                            <div class="col-sm-12">
                                                <ul class="preview-list ">
                                                    <li class="preview-item">
                                                        <button type="submit" class="btn btn-primary">Update</button>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--col-->
                                        </div>
                                    </form>
                                    <!--row-->
                                </div>
                                <!--card inner-->
                            </div>
                            <!--card-->
                        </div>
                    </div>
                </div>

                <!--.nk-block -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/editors/summernote.css')); ?>?ver=3.0.3">
<script src="<?php echo e(asset('assets/js/libs/editors/summernote.js')); ?>?ver=3.0.3"></script>
<script>
    $(document).ready(function() {
  $('#summernote').summernote({
        placeholder: 'Enter Detail',
        height: 200
      });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\allprojects\ggPlayerDashboard\resources\views/updatepassword.blade.php ENDPATH**/ ?>